[app]

title = Assistant Vocal Intelligent
package.name = assistantvocal
package.domain = org.dekal

source.dir = .
source.include_exts = py,json,kv,png,jpg,ttf

version = 0.1

requirements = python3,kivy,pyjnius,plyer,vosk,numpy

# Inclure le dossier du modèle Vosk dans l'APK (à télécharger avant build)
# source.include_patterns = modele_vosk/*

orientation = portrait
fullscreen = 0

icon.filename = %(source.dir)s/icon.png

# Permissions Android nécessaires aux fonctionnalités de l'assistant
android.permissions = RECORD_AUDIO,CAMERA,FLASHLIGHT,BLUETOOTH,BLUETOOTH_ADMIN,ACCESS_FINE_LOCATION,ACCESS_COARSE_LOCATION,SEND_SMS,INTERNET,WAKE_LOCK,MODIFY_AUDIO_SETTINGS

android.api = 33
android.minapi = 23
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a

android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
